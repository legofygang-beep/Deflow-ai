import { getMarkets } from '../scripts/orderly.js';

test('mock orderly markets', async () => {
  if (!process.env.ORDERLY_API_KEY) {
    expect(true).toBe(true);
  } else {
    const mkts = await getMarkets();
    expect(Array.isArray(mkts)).toBe(true);
  }
});
