# Solscan + Dexscreener + Orderly Agent (Hackathon Project)

This repo integrates Solscan, Dexscreener, and Orderly Network APIs into a LangChain-style agent for DeFi research + trading.

## Setup

```bash
npm install
cp .env.example .env   # fill in keys
```

## Run Demo

```bash
npm run demo
```

## Tests

- CI runs in **mock mode**.
- Locally, you can enable live mode by setting your `.env` with valid keys:

```bash
npm test
```

## Features

- ✅ Solscan wallet & token scans
- ✅ Dexscreener token discovery
- ✅ Orderly perp trading (with safety confirm)
- ✅ Fancy CLI output for hackathon judging
