import axios from 'axios';
import 'dotenv/config';

const BASE = 'https://pro-api.solscan.io/v1.0';

export async function getWalletTokens(wallet) {
  try {
    const res = await axios.get(`${BASE}/account/tokens`, {
      headers: { token: process.env.SOLSCAN_API_KEY },
      params: { account: wallet }
    });
    return res.data.data.map(t => ({
      token: t.tokenSymbol || t.tokenAddress,
      balance: t.tokenAmount.uiAmount
    }));
  } catch (e) {
    console.error("Solscan error", e.response?.data || e.message);
    return [];
  }
}