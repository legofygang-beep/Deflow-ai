import 'dotenv/config';
import chalk from 'chalk';
import Table from 'cli-table3';
import { getWalletTokens } from './solscan.js';
import { getTopTokens } from './dexscreener.js';
import { getMarkets } from './orderly.js';

async function runDemo() {
  console.log(chalk.bold.cyan("\n🚀 Hackathon Agent Demo Start\n"));

  console.log(chalk.yellow("Step 1: Fetching wallet tokens from Solscan..."));
  const walletData = await getWalletTokens("So11111111111111111111111111111111111111112");
  const walletTable = new Table({ head: ["Token", "Balance"], colWidths: [30, 20] });
  walletData.forEach(tok => walletTable.push([tok.token, tok.balance]));
  console.log(walletTable.toString());

  console.log(chalk.yellow("\nStep 2: Fetching trending tokens from Dexscreener..."));
  const tokens = await getTopTokens();
  const tokTable = new Table({ head: ["Symbol", "Price", "Liquidity"], colWidths: [15, 15, 15] });
  tokens.slice(0, 5).forEach(t => tokTable.push([t.symbol, `$${t.price}`, t.liquidity]));
  console.log(tokTable.toString());

  console.log(chalk.yellow("\nStep 3: Fetching markets from Orderly..."));
  const markets = await getMarkets();
  const mktTable = new Table({ head: ["Symbol", "Status"], colWidths: [20, 20] });
  markets.slice(0, 5).forEach(m => mktTable.push([m.symbol, m.status]));
  console.log(mktTable.toString());

  console.log(chalk.bold.green("\n✅ Demo Finished Successfully!\n"));
}

runDemo();
