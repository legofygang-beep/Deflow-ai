import axios from 'axios';

export async function getTopTokens() {
  try {
    const res = await axios.get('https://api.dexscreener.com/latest/dex/tokens');
    return res.data.pairs.map(p => ({
      symbol: p.baseToken.symbol,
      price: p.priceUsd,
      liquidity: p.liquidity?.usd || 0
    }));
  } catch (e) {
    console.error("Dexscreener error", e.message);
    return [];
  }
}