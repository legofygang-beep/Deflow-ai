import axios from 'axios';
import 'dotenv/config';

const BASE = 'https://api.orderly.org';

export async function getMarkets() {
  try {
    const res = await axios.get(`${BASE}/v1/public/info`);
    return res.data.data.rows.map(m => ({
      symbol: m.symbol,
      status: m.status
    }));
  } catch (e) {
    console.error("Orderly error", e.message);
    return [];
  }
}